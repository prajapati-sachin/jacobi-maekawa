#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
	// toggle(); // This toggles the system trace on or off
	printf(1, "sum of 10 and -6 is: %d\n",add(10,-6));
	exit();
}
